<?php $__env->startSection('title', 'Novo evento'); ?>
<?php $__env->startSection('content'); ?>
    <form>
        <div class="d-flex justify-content-between">
            <div class="d-flex flex-fill">
                <input type="text" name="search" class="form-control w-50 mr-2" value="<?php echo e($search); ?> " placeholder="Pesquisar...">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
            <a href="<?php echo e(route('organization.events.create')); ?>" class="btn btn-primary">Novo evento</a>
        </div>
    </form>
    <table class="table mt-4">
        <thead class="thead bg-white">
            <tr>
                <th>Nome</th>
                <th>Palestrante</th>
                <th>Início</th>
                <th>Fim</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle"><?php echo e($event->name); ?></td>
                    <td class="align-middle"><?php echo e($event->speaker_name); ?></td>
                    <td class="align-middle"><?php echo e($event->start_date_formatted); ?></td>
                    <td class="align-middle"><?php echo e($event->end_date_formatted); ?></td>
                    <td class="align-middle">
                        <div class="d-flex align-items-center">
                            <a href="<?php echo e(route('organization.events.show', $event->id )); ?>" class="btn btn-sm btn-info mr-2">
                                <i class="fa fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('organization.events.edit', $event->id)); ?>" class="btn btn-sm btn-primary mr-2">
                                <i class="fa fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('organization.events.destroy', $event->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger confirm-submit">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($events->withQueryString()->links()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/organization/events/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LARAEVENTS\resources\views/Organization/Events/index.blade.php ENDPATH**/ ?>