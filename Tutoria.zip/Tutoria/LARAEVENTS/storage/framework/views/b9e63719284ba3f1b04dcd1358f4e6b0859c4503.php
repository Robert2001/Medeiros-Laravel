<?php $__env->startSection('title', $event->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">InformaÃ§Ãµes gerais</div>
                <div class="card-body">
                    <ul class="list-group text-center">
                        <li class="list-group-item">
                            <span class="font-weight-bold mb-1">Palestrante: </span>
                            <span><?php echo e($event->speaker_name); ?></span>
                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold mb-1">InÃ­cio: </span>
                            <?php echo e($event->start_date_formatted); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold mb-1">Fim: </span>
                            <?php echo e($event->end_date_formatted); ?>

                        </li>
                        <li class="list-group-item">
                            <span class="font-weight-bold mb-1">PÃºblico-alvo: </span>
                            <span><?php echo e($event->target_audience); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header bg-primary text-white">Participantes</div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('organization.events.subscription.store', $event->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <select class="form-control" name="user_id">
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $allParticipantUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>">
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-lg-2">
                        <button type="submit" class="btn btn-success">Incluir</button>
                    </div>
                </div>
            </form>
            <table class="table bg-white mt-3">
                <thead>
                    <th>Nome</th>
                    <th class="text-right">AÃ§Ãµes</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $event->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td class="text-right">
                                <div class="d-flex align-items-center justify-content-end">
                                    <?php if($eventStartDateHasPassed): ?>
                                        <form method="POST" action="<?php echo e(route('organization.events.presences', [
                                            'event' => $event->id,
                                            'user' => $user->id
                                        ])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm mr-2 <?php echo e($user->pivot->present ? 'btn-danger' : 'btn-succes'); ?>">
                                                <?php echo e($user->pivot->present ? 'Remover presença' : 'Assinar presença'); ?>

                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    <?php if(!$eventEndDateHasPassed): ?>
                                        <form method="POST" action="<?php echo e(route('organization.events.subscription.destroy', [
                                                'event' => $event->id,
                                                'user' => $user->id
                                            ])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger">Remover inscrição</button>
                                        </form>
                                    <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LARAEVENTS\resources\views/organization/events/show.blade.php ENDPATH**/ ?>