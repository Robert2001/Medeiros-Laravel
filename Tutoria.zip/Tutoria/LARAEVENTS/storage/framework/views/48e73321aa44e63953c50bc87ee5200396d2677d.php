<?php $__env->startSection('title', 'Novo evento'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('organization.events.store')); ?>" method="POST" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="name">Nome</label>
                    <input
                        type="text"
                        class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>"
                        id="name"
                        name="name"
                        value="<?php echo e(old('name', isset($event) ? $event->name : '')); ?>"
                    >
                    <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="speaker_name">Nome do palestrante</label>
                    <input
                        type="text"
                        class="form-control <?php echo e($errors->has('speaker_name') ? 'is-invalid' : ''); ?>"
                        id="speaker_name"
                        name="speaker_name"
                        value="<?php echo e(old('speaker_name', isset($event) ? $event->speaker_name : '')); ?>"
                    >
                    <div class="invalid-feedback"><?php echo e($errors->first('speaker_name')); ?></div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="form-group">
                    <label for="start_date">Data de início</label>
                    <input
                        type="text"
                        class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>"
                        id="start_date"
                        name="start_date"
                        value="<?php echo e(old('start_date', isset($event) ? $event->start_date_formatted : '')); ?>"
                        data-mask="00/00/0000 00:00"
                    >
                    <div class="invalid-feedback"><?php echo e($errors->first('start_date')); ?></div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="form-group">
                    <label for="end_date">Data de fim</label>
                    <input
                        type="text"
                        class="form-control date <?php echo e($errors->has('end_date') ? 'is-invalid' : ''); ?>"
                        id="end_date"
                        name="end_date"
                        value="<?php echo e(old('end_date', isset($event) ? $event->end_date_formatted : '')); ?>"
                        data-mask="00/00/0000 00:00"
                    >
                    <div class="invalid-feedback"><?php echo e($errors->first('end_date')); ?></div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="form-group">
                    <label for="participants_limit">Limite de participantes</label>
                    <input
                        type="number"
                        class="form-control <?php echo e($errors->has('participants_limit') ? 'is-invalid' : ''); ?>"
                        id="participants_limit"
                        name="participants_limit"
                        min="1"
                        value="<?php echo e(old('participants_limit', isset($event) ? $event->participants_limit : '')); ?>"
                    >
                    <div class="invalid-feedback"><?php echo e($errors->first('participants_limit')); ?></div>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label for="target_audience">Público alvo</label>
                    <textarea
                        class="form-control <?php echo e($errors->has('target_audience') ? 'is-invalid' : ''); ?>"
                        id="target_audience"
                        name="target_audience"
                        rows="3"
                    ><?php echo e(old('target_audience', isset($event) ? $event->target_audience : '')); ?></textarea>
                    <div class="invalid-feedback"><?php echo e($errors->first('target_audience')); ?></div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-success mt-2">Salvar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraEvents\resources\views/Organization/Events/index.blade.php ENDPATH**/ ?>