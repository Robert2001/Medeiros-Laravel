<?php $__env->startSection('title', 'Editar evento'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('organization.events.update', $event->id)); ?>" method="POST" autocomplete="off">
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('organization.Events._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\LARAEVENTS\resources\views/organization/events/edit.blade.php ENDPATH**/ ?>