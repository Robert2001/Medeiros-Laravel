<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>">
</head>
<body>
<h1 class="text-center my-4">Cria conta</h1>

<div class="card shadow my-5 w-75 mx-auto">
<div class="card-body">
<form action="<?php echo e(route('auth.register.store')); ?>"method="POST">

<?php echo csrf_field(); ?>

<div class="row">
    <div class="col-12">
        <div class="form-group">
            <input
            type="text"
            name="user[name]"
            class="form-control <?php echo e($errors->has('user.name')? 'is-invalid' : ''); ?> "
            placeholder="Nome"
            value="<?php echo e(old('user.name')); ?>"
            >
           <div class="invalidfeedback"> <?php echo e($errors->first('user.name')); ?></div>
        </div>
    </div>

<div class="col-md-6">
    <div class="form-group">
         <input
        type="email"
        name="user[email]"
        class="form-control <?php echo e($errors->has('user.email')? 'is-invalid' : ''); ?>"
        placeholder="email"
        value="<?php echo e(old('user.email')); ?>"
         >
        <div class="invalidfeedback"> <?php echo e($errors->first('user.email')); ?> </div>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <input
        type="text"
        name="user[cpf]"
        class="form-control cpf <?php echo e($errors->has('user.cpf')? 'is-invalid' : ''); ?> "
        placeholder="CPF"
        value="<?php echo e(old('user.cpf')); ?>"
        >
        <div class="invalidfeedback"> <?php echo e($errors->first('user.cpf')); ?></div>
    </div>
</div>
        <div class="col-12 col-md-6" >
            <div class="form-group">
                <input
                type="password"
                name="user[password]"
                class="form-control <?php echo e($errors->has('user.password')? 'is-invalid' : ''); ?> "
                placeholder="Senha"

            >
                 <div class="invalidfeedback"> <?php echo e($errors->first('user.password')); ?></div>
            </div>
        </div>
    <div class="col-12 col-md-6" >
        <div class="form-group">
            <input
            type="password"
            name="user[password_confirmation]"
            class="form-control"
            placeholder="Confirma Senha"

            >
        </div>
    </div>
</div>


<hr>

<div class="row mt-4">
 <div class="col-md-3">
    <div class="form-group ">
        <input
            type="text"
            name="address[cep]"
            class="form-control cep <?php echo e($errors->has('address.cep')? 'is-invalid' : ''); ?> "
            placeholder="CEP"
            value="<?php echo e(old('address.cep')); ?>"
            id="cep"
        >
             <div class="invalidfeedback"> <?php echo e($errors->first('address.cep')); ?></div>
    </div>
</div>
<div class="col-md-2">
    <div class="form-group">
        <input
            type="text"
            name="address[uf]"
            class="form-control uf <?php echo e($errors->has('address.uf')? 'is-invalid' : ''); ?>"
            placeholder="UF"
            value="<?php echo e(old('address.uf')); ?>"
            id="uf"
        >
       <div class="invalidfeedback"> <?php echo e($errors->first('address.uf')); ?></div>
    </div>
</div>

<div class="col-md-7">
    <div class="form-group ">
        <input
            type="text"
            name="address[city]"
            class="form-control  <?php echo e($errors->has('address.city')? 'is-invalid' : ''); ?> "
            placeholder="Cidade"
            value="<?php echo e(old('address.city')); ?>"
            id="city"
        >
       <div class="invalidfeedback"> <?php echo e($errors->first('address.city')); ?></div>
    </div>
</div>

<div class="col-md-9">
    <div class="form-group">
        <input
            type="text"
            name="address[street]"
            class="form-control <?php echo e($errors->has('address.street')? 'is-invalid' : ''); ?> "
            placeholder="Logradouro"
            value="<?php echo e(old('address.street')); ?>"
            id="street"
        >
      <div class="invalidfeedback"> <?php echo e($errors->first('address.street')); ?></div>
    </div>
</div>

<div class="col-md-3">
    <div class="form-group">
           <input
            type="text"
            name="address[number]"
            class="form-control <?php echo e($errors->has('address.number')? 'is-invalid' : ''); ?> "
            placeholder="Número"
            value="<?php echo e(old('address.number')); ?>"
           >
        <div class="invalidfeedback"> <?php echo e($errors->first('address.number')); ?></div>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <input
            type="text"
            name="address[district]"
            class="form-control <?php echo e($errors->has('address.district')? 'is-invalid' : ''); ?>"
            placeholder="Bairro"
            value="<?php echo e(old('address.district')); ?>"
            id="district"
        >
       <div class="invalidfeedback"> <?php echo e($errors->first('address.district')); ?></div>
    </div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <input
            type="text"
            name="address[complement]"
            class="form-control <?php echo e($errors->has('address.complement')? 'is-invalid' : ''); ?>"
            placeholder="Complemento"
            value="<?php echo e(old('address.complementt')); ?>"
        >
         <div class="invalidfeedback"> <?php echo e($errors->first('address.complement')); ?></div>
    </div>
</div>


<hr>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="form-group">
        <input
            type="text"
            name="phones[0][number]"
            class="form-control phone <?php echo e($errors->has('phones.0.number')? 'is-invalid' : ''); ?>"
            placeholder="Telefone"
            value="<?php echo e(old('phones.0.number')); ?>"
        >
           <div class="invalidfeedback"><?php echo e($errors->first('phones.0.number')); ?></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
          <input
            type="text"
            name="phones[1][number]"
            class="form-control cellphone <?php echo e($errors->has('phones.1.number')? 'is-invalid' : ''); ?>"
            placeholder="Celular"
            value="<?php echo e(old('phones.1.number')); ?>"
          >
           <div class="invalidfeedback"><?php echo e($errors->first('phones.1.number')); ?></div>
        </div>
    </div>
</div>


           <button type="submit" class="btn btn-success btn-block mt-3">Cadastrar</button>

           </form>
        </div>
    </div>

    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery-mask/jquery.mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/auth/register.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp2\htdocs\LARAEVENTS\resources\views/auth/register.blade.php ENDPATH**/ ?>