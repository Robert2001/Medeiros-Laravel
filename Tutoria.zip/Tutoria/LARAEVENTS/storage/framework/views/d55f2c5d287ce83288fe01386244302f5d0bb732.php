<?php $__env->startSection('title','Emerson ama perdidamente Elke'); ?>
<?php $__env->startSection('content'); ?>
    Dashborad organização
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraEvents\resources\views/Organization/dashboard/index.blade.php ENDPATH**/ ?>