@extends('layouts.panel')
@section('title','Emerson ama perdidamente Elke')
@section('content')
    Dashboard
@endsection
