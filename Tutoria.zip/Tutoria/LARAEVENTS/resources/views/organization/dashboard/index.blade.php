@extends('layouts.panel')
@section('title','March esteve aqui')
@section('content')
    Dashborad organização
@endsection
